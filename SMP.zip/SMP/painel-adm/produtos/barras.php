<?php 

require_once('../barras.php');
geraCodigoBarra($_POST['codigo']);

 ?>