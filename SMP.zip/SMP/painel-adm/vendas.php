<?php
$pag = 'vendas';
@session_start();

require_once('../conexao.php');
require_once('verificar-permissao.php');

//$_GET['id']


?>