<?php
$nome_sistema= "Mais Polpas";

$url_sistema = "http://localhost/smp/"; //é preciso configurar essa url para gerar os relatorios, ela deve apontar para a raiz do seu dominio (https://www.google.com/) com a barra no final e o protocolo http ou https de acordo com seu dominio no inicio.

$telefone_sistema = "(61) 99522-5445";
$endereco_sistema = "Enderço X";
$rodape_relatorios = "Sistema Desenvolvido por Gabriel Caetano!";

$servidor = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'SMP';


$relatorio_pdf = 'Sim';
?>